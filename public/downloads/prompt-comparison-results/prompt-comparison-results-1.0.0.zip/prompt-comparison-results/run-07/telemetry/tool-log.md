# Tool log

Bootstrap command: mkdir -p telemetry; Python recorded start time and ran/logged cat task.md.
Bootstrap stdout/stderr: task contents shown below; no other output.

## Command
```sh
cat task.md
```
### stdout
```text
读取 input/sales.csv 与 data-dictionary.md，生成两周销售周报和字典要求的三份 CSV。遵守字典口径，不改输入。输出到 output/。

额外交付逐行处理决定到周报关键数字的核对说明，列明重复、缺日期、退款和零基数；交付前按原始行与地区总和独立复核，保存实际检查记录。

```
### stderr
```text

```
Exit code: 0

## Command
```sh
cat data-dictionary.md && cat input/sales.csv
```
### stdout
```text

```
### stderr
```text
cat: data-dictionary.md: No such file or directory

```
Exit code: 1

## Command
```sh
rg --files -g "!telemetry/**"
```
### stdout
```text
task.md
input/sales.csv
input/data-dictionary.md

```
### stderr
```text

```
Exit code: 0

## Command
```sh
cat input/data-dictionary.md input/sales.csv
```
### stdout
```text
# 数据字典与计算口径

文件 `sales.csv`：UTF-8，逗号分隔，首行为表头。46 条合成记录，金额单位人民币元（CNY），小数点为英文句点。

| 字段 | 类型 | 定义 |
|---|---|---|
| order_id | 文本 | 交易记录唯一 ID。退款有独立 ID，不覆盖原订单 |
| date | ISO 日期或空 | 已明确为业务本地自然日，没有时区换算；缺失不自行补齐 |
| region | 文本 | 华东、华南、西南 |
| product | 文本 | 笔记本、收纳盒、台灯 |
| net_sales | 十进制金额 | 正数为销售，负数为退款，零为有效记录。已经是净额，不再扣同一退款 |

处理顺序：先核对 ID 和字段，再处理日期，最后分组计算。

1. 相同 ID 且全部字段完全一致，只保留 CSV 中第一条；逐行台账保留被剔除行号。相同 ID 内容冲突则停止，不能套用此规则静默丢弃。
2. 日期空缺隔离，金额记入待核对清单；非法日期或范围外日期停止并说明。
3. 上期含 2026-08-31—09-06，本期含 2026-09-07—09-13，两个区间均包含首尾日期。
4. 每个地区分别对有效 `net_sales` 求和。总额等于三个地区之和。
5. 增减额 = 本期 − 上期；环比百分比 = 增减额 ÷ 上期 × 100。上期为零时用字符串 N/A，不能用数值零替代。环比按四舍五入保留两位小数。
6. Top 3 只统计本期，按产品净额降序，相同金额按产品名称 Unicode 顺序排。计入负数退款。

输出 CSV 表头固定：

- `region-summary.csv`：`region,prior_cny,current_cny,change_cny,change_percent`；按华东、华南、西南、总计排列。百分比存数值文本，如 87.04 表示 87.04%，不是 0.8704。
- `top-products.csv`：`rank,product,current_cny`。
- `row-ledger.csv`：`source_line,order_id,decision,week,net_sales`；原表行号包含表头，第一条为第 2 行。decision 为 included、duplicate 或 missing-date；未纳入时 week 留空，纳入时为 1 或 2。

本期纳入退款 R043；上期纳入 R044。O001 的第二次出现是完全重复；O046 缺日期。西南上期七条零金额用于练习零基数，不是数据缺失。不要把这些作者预设条件推断为真实商店的业务原因。
order_id,date,region,product,net_sales
O001,2026-08-31,华东,笔记本,100.25
O002,2026-08-31,华南,收纳盒,200.25
O003,2026-08-31,西南,台灯,0.00
O004,2026-09-01,华东,收纳盒,110.25
O005,2026-09-01,华南,台灯,210.25
O006,2026-09-01,西南,笔记本,0.00
O007,2026-09-02,华东,台灯,120.25
O008,2026-09-02,华南,笔记本,220.25
O009,2026-09-02,西南,收纳盒,0.00
O010,2026-09-03,华东,笔记本,130.25
O011,2026-09-03,华南,收纳盒,230.25
O012,2026-09-03,西南,台灯,0.00
O013,2026-09-04,华东,收纳盒,140.25
O014,2026-09-04,华南,台灯,240.25
O015,2026-09-04,西南,笔记本,0.00
O016,2026-09-05,华东,台灯,150.25
O017,2026-09-05,华南,笔记本,250.25
O018,2026-09-05,西南,收纳盒,0.00
O019,2026-09-06,华东,笔记本,160.25
O020,2026-09-06,华南,收纳盒,260.25
O021,2026-09-06,西南,台灯,0.00
O022,2026-09-07,华东,收纳盒,170.25
O023,2026-09-07,华南,台灯,270.25
O024,2026-09-07,西南,笔记本,150.25
O025,2026-09-08,华东,台灯,180.25
O026,2026-09-08,华南,笔记本,280.25
O027,2026-09-08,西南,收纳盒,160.25
O028,2026-09-09,华东,笔记本,190.25
O029,2026-09-09,华南,收纳盒,290.25
O030,2026-09-09,西南,台灯,170.25
O031,2026-09-10,华东,收纳盒,200.25
O032,2026-09-10,华南,台灯,300.25
O033,2026-09-10,西南,笔记本,180.25
O034,2026-09-11,华东,台灯,210.25
O035,2026-09-11,华南,笔记本,310.25
O036,2026-09-11,西南,收纳盒,190.25
O037,2026-09-12,华东,笔记本,220.25
O038,2026-09-12,华南,收纳盒,320.25
O039,2026-09-12,西南,台灯,200.25
O040,2026-09-13,华东,收纳盒,230.25
O041,2026-09-13,华南,台灯,330.25
O042,2026-09-13,西南,笔记本,210.25
R043,2026-09-10,华东,笔记本,-120.50
R044,2026-09-06,华南,台灯,-40.25
O001,2026-08-31,华东,笔记本,100.25
O046,,华东,收纳盒,199.99

```
### stderr
```text

```
Exit code: 0

## Command
`python3` heredoc: validated input fields and IDs, classified all source rows, generated the three CSVs, weekly-report.md and reconciliation.md with Decimal arithmetic; input hash unchanged.
### stdout
```json
{
  "rows": 46,
  "summary": [
    [
      "华东",
      "911.75",
      "1281.25",
      "369.50",
      "40.53"
    ],
    [
      "华南",
      "1571.50",
      "2101.75",
      "530.25",
      "33.74"
    ],
    [
      "西南",
      "0.00",
      "1261.75",
      "1261.75",
      "N/A"
    ],
    [
      "总计",
      "2483.25",
      "4644.75",
      "2161.50",
      "87.04"
    ]
  ],
  "top": [
    [
      1,
      "台灯",
      "1661.75"
    ],
    [
      2,
      "收纳盒",
      "1561.75"
    ],
    [
      3,
      "笔记本",
      "1421.25"
    ]
  ],
  "source_sha256": "e2ad0770e43d1bab02f2c61d5d24f5a96a0c9f80dcf878d7aac00fe41c2e0c80"
}
```
### stderr
(empty)
Exit code: 0

## Command
`python3` heredoc: independently reread original CSV, checked original-line integer-cent totals, regional sums, percentages, every ledger row, exclusions, refunds, zero base, product ranking and input SHA-256.
### stdout
64 checks passed; saved output/checks.md
### stderr
(empty)
Exit code: 0
